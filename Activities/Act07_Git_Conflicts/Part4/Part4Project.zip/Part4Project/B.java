public class B {

	public void bar() {
	}

}
