# Part 2

This is a sample README.md written in Markdown. Markdown is a very
simple syntax that can easily be translated into HTML. Many
web services, including GitHub, will render Markdown on the fly.

For more information on Markdown, checkout the following:

	- Markdown - as created by John Gruber: https://daringfireball.net/projects/markdown/
	- CommonMark - An effort to standardize Markdown: http://commonmark.org/
	- Pandoc - One of my favorite tools for converting Markdown to html, pdf, docx, etc.: http://pandoc.org/


